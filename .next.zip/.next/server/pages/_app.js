var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__1cd5aa2a._.js")
R.m(42397)
module.exports=R.m(42397).exports
