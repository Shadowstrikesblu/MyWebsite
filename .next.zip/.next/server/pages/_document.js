var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__d9b4eca7._.js")
R.c("server/chunks/ssr/[root-of-the-server]__52ce4172._.js")
R.m(89632)
module.exports=R.m(89632).exports
