var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__7a468dfa._.js")
R.c("server/chunks/8070d_next_dist_f3863d85._.js")
R.c("server/chunks/[root-of-the-server]__1a9e2a98._.js")
R.c("server/chunks/8070d_next_dist_b4063b45._.js")
R.c("server/chunks/8070d_next_dist_34d532ca._.js")
R.m(91110)
R.m(66065)
module.exports=R.m(66065).exports
