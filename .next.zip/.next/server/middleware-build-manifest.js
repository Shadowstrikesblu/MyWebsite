globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/bc329234117cb6ca.js",
      "static/chunks/17496376c2f1c451.js",
      "static/chunks/turbopack-ba615f4b37678648.js"
    ],
    "/_error": [
      "static/chunks/9eaebd9f3af65554.js",
      "static/chunks/17496376c2f1c451.js",
      "static/chunks/turbopack-18209bd2680b49a8.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/217087b657249343.js",
    "static/chunks/ab5a3da32adde495.js",
    "static/chunks/d9db9e28504379f9.js",
    "static/chunks/cf87de8aa3e42ec1.js",
    "static/chunks/turbopack-26ca092e1166f642.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];