module.exports=[38304,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},97814,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(38304).default,width:256,height:256}}];

//# sourceMappingURL=OneDrive_Documents_2027_PortFolioWbesite_MyWebsite_src_app_26961199._.js.map