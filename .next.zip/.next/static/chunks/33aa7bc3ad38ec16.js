__turbopack_load_page_chunks__("/_app", [
  "static/chunks/bc329234117cb6ca.js",
  "static/chunks/17496376c2f1c451.js",
  "static/chunks/turbopack-ba615f4b37678648.js"
])
