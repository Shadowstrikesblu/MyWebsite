__turbopack_load_page_chunks__("/_error", [
  "static/chunks/9eaebd9f3af65554.js",
  "static/chunks/17496376c2f1c451.js",
  "static/chunks/turbopack-18209bd2680b49a8.js"
])
